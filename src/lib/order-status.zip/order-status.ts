import type { OrderResponse } from '@/services/orderApi';

export interface OrderStatusMeta {
  color: 'green' | 'gold' | 'blue' | 'red' | 'default' | 'magenta' | 'purple' | 'cyan';
  label: string;
  step: number;
  description: string;
}

export function getOrderStatusMeta(status: string): OrderStatusMeta {
  switch (status.toUpperCase()) {
    case 'CREATED':
    case 'PENDING':
      return {
        color: 'gold',
        label: 'Chờ xử lý',
        step: 1,
        description: 'Đơn hàng đã được ghi nhận và đang chờ xử lý.',
      };
    case 'CONFIRMED':
    case 'PROCESSING':
    case 'PAID':
      return {
        color: 'blue',
        label: 'Đang xử lý',
        step: 2,
        description: 'Hệ thống đang xác nhận thanh toán và chuẩn bị hàng.',
      };
    case 'SHIPPING':
      return {
        color: 'cyan',
        label: 'Đang giao',
        step: 3,
        description: 'Đơn hàng đã được bàn giao cho đơn vị vận chuyển.',
      };
    case 'COMPLETED':
    case 'DELIVERED':
      return {
        color: 'green',
        label: 'Hoàn tất',
        step: 4,
        description: 'Đơn hàng đã hoàn tất thành công.',
      };
    case 'PAYMENT_FAILED':
      return {
        color: 'magenta',
        label: 'Lỗi thanh toán',
        step: 2,
        description: 'Giao dịch chưa thành công. Vui lòng thử lại hoặc chọn phương thức khác.',
      };
    case 'FAILED':
    case 'CANCELLED':
      return {
        color: 'red',
        label: 'Thất bại',
        step: 2,
        description: 'Đơn hàng không thể hoàn tất.',
      };
    default:
      return {
        color: 'default',
        label: status || 'Đang cập nhật',
        step: 1,
        description: 'Trạng thái đơn hàng đang được cập nhật.',
      };
  }
}

export function getOrderTrackingSteps(order: Pick<OrderResponse, 'status'>) {
  const meta = getOrderStatusMeta(order.status);
  const isError = ['FAILED', 'PAYMENT_FAILED', 'CANCELLED'].includes(order.status.toUpperCase());

  return [
    { title: 'Đã tiếp nhận', status: 'finish' as const },
    {
      title: isError ? 'Có sự cố' : 'Đang xử lý',
      status: isError ? 'error' as const : meta.step >= 2 ? 'finish' as const : 'process' as const,
    },
    {
      title: 'Vận chuyển',
      status: isError ? 'wait' as const : meta.step >= 3 ? 'finish' as const : meta.step === 2 ? 'process' as const : 'wait' as const,
    },
    {
      title: 'Hoàn tất',
      status: isError ? 'wait' as const : meta.step >= 4 ? 'finish' as const : 'wait' as const,
    },
  ];
}
